import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import LoginPage from "./components/LoginPage";
import RegisterPage from "./components/RegisterPage";
import DashboardPage from "./components/DashboardPage";

function App() {
  return (
    <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
           <Route path="/Register" element={<RegisterPage />} />
           <Route path="/Dashboard" element={<DashboardPage />} />
        </Routes>
    </BrowserRouter>
  );
}

export default App;