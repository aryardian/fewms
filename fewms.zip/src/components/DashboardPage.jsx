import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeftIcon, ChevronRightIcon } from '@heroicons/react/20/solid'
import loginImage from '../assets/actwh.jpeg';
import bgImage from '../assets/hbg.jpeg';
import regisimg from '../assets/regisimg.jpeg';
import IsiPage from "../components/IsiPage";

const DashboardPage = () => {
  [
  { id: 1, title: 'Back End Developer', department: 'Engineering', type: 'Full-time', location: 'Remote' },
  { id: 2, title: 'Front End Developer', department: 'Engineering', type: 'Full-time', location: 'Remote' },
  { id: 3, title: 'User Interface Designer', department: 'Design', type: 'Full-time', location: 'Remote' },
]


  return (
    <>
<div className="font-mono">

<div className="w-full h-screen flex flex-col lg:flex-row items-start">
 {/* Image Section */}
 <div className="relative bg-sky-300 w-full lg:w-1/4 h-1/4 lg:h-full flex flex-col overscroll-auto border-solid border-2">
 <div className="absolute top-[20%] left-[10%] flex flex-col z-10">
 <div className="hidden lg:block w-full h-full pb-4 object-cover">
 <a 
  href="#"
  className="text-xl text-stone-800 hover:text-red-400">
  InBond
  </a>
</div>
<div className="hidden lg:block w-full h-full pb-4 object-cover">
 <a 
  href="#"
  className="text-xl text-stone-800 hover:text-red-400">
  OutBond
  </a>
</div>
<div className="hidden lg:block w-full h-full pb-4 object-cover">
 <a 
  href="#"
  className="text-xl text-stone-800 hover:text-red-400">
  Stock
  </a>
</div>
<div className="hidden lg:block w-full h-full pb-4 object-cover">
 <a 
  href="#"
  className="text-xl text-stone-800 hover:text-red-400">
  Staff
  </a>
</div>
<div className="hidden lg:block w-full h-full pb-4 object-cover">
 <a 
  href="#"
  className="text-xl text-stone-800 hover:text-red-400">
  Logout
  </a>
</div>
</div>
</div>


<div className="w-full lg:w-3/4 flex flex-col p-10 lg:p-20 justify-center">
<div className="w-full flex flex-col mb-5">
<div>
<h3 className="text-gray-400 text-xl"> InBond</h3>
</div>

{/* table */}
<div className="pl-4 pt-10 pb-10">
<table className="table-auto">
  <thead>
    <tr>
      <th className="border-collapse border border-slate-500">No</th>
      <th className="border-collapse border border-slate-500">Song</th>
      <th className="border-collapse border border-slate-500">Artist</th>
      <th className="border-collapse border border-slate-500">Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td className="border-collapse border border-slate-500">1</td>
      <td className="border-collapse border border-slate-500">The Sliding Mr. Bones (Next Stop, Pottersville)</td>
      <td className="border-collapse border border-slate-500">Malcolm Lockyer</td>
      <td className="border-collapse border border-slate-500">1961</td>
    </tr>
    <tr>
      <td className="border-collapse border border-slate-500">2</td>
      <td className="border-collapse border border-slate-500">Witchy Woman</td>
      <td className="border-collapse border border-slate-500">The Eagles</td>
      <td className="border-collapse border border-slate-500">1972</td>
    </tr>
    <tr>
      <td className="border-collapse border border-slate-500">3</td>
      <td className="border-collapse border border-slate-500">Shining Star</td>
      <td className="border-collapse border border-slate-500">Earth, Wind, and Fire</td>
      <td className="border-collapse border border-slate-500">1975</td>
    </tr>
     <tr>
      <td className="border-collapse border border-slate-500">4</td>
      <td className="border-collapse border border-slate-500">Shining Star</td>
      <td className="border-collapse border border-slate-500">Earth, Wind, and Fire</td>
      <td className="border-collapse border border-slate-500">1975</td>
    </tr>
     <tr>
      <td className="border-collapse border border-slate-500">5</td>
      <td className="border-collapse border border-slate-500">Shining Star</td>
      <td className="border-collapse border border-slate-500">Earth, Wind, and Fire</td>
      <td className="border-collapse border border-slate-500">1975</td>
    </tr>
  </tbody>
</table>
</div>

{/* Pagination */}
<div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6">
      <div className="flex flex-1 justify-between sm:hidden">
        <a
          href="#"
          className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Previous
        </a>
        <a
          href="#"
          className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Next
        </a>
      </div>
      <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
        <div>
          <p className="text-sm text-gray-700">
            Showing <span className="font-medium">1</span> to <span className="font-medium">10</span> of{' '}
            <span className="font-medium">97</span> results
          </p>
        </div>
        <div>
          <nav aria-label="Pagination" className="isolate inline-flex -space-x-px rounded-md shadow-sm">
            <a
              href="#"
              className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
            >
              <span className="sr-only">Previous</span>
              <ChevronLeftIcon aria-hidden="true" className="h-5 w-5" />
            </a>
            {/* Current: "z-10 bg-indigo-600 text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600", Default: "text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:outline-offset-0" */}
            <a
              href="#"
              aria-current="page"
              className="relative z-10 inline-flex items-center bg-indigo-600 px-4 py-2 text-sm font-semibold text-white focus:z-20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              1
            </a>
            <a
              href="#"
              className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
            >
              2
            </a>
            <a
              href="#"
              className="relative hidden items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 md:inline-flex"
            >
              3
            </a>
            <span className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-700 ring-1 ring-inset ring-gray-300 focus:outline-offset-0">
              ...
            </span>
            <a
              href="#"
              className="relative hidden items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0 md:inline-flex"
            >
              8
            </a>
            <a
              href="#"
              className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
            >
              9
            </a>
            <a
              href="#"
              className="relative inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
            >
              10
            </a>
            <a
              href="#"
              className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
            >
              <span className="sr-only">Next</span>
              <ChevronRightIcon aria-hidden="true" className="h-5 w-5" />
            </a>
          </nav>
        </div>
      </div>
    </div>
</div>
</div>
</div>
</div>

</>


);
};
export default DashboardPage;