import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import loginImage from '../assets/actwh.jpeg';
import bgImage from '../assets/hbg.jpeg';
import regisimg from '../assets/regisimg.jpeg'

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    alert('Register Sukses');
  };

  return (
    <div className="font-mono bg-gray-400">
      <div className="w-full h-screen flex flex-col lg:flex-row items-start">
        {/* Image Section */}
        <div className="relative w-full lg:w-1/2 h-1/2 lg:h-full flex flex-col">
          <div className="absolute top-[20%] left-[10%] flex flex-col z-10">
            <h1 className="hidden text-4xl text-white font-bold my-4">Welcome To</h1>
            <p className="hidden text-xl text-white font-normal">PT. Kemarin Bisa Makan</p>
          </div>

          <img
            src={regisimg}
            alt="Login Background"
            className="hidden lg:block w-full h-full object-cover"
          />
        </div>

        {/* Form Section */}
        <div className="w-full lg:w-1/2 flex flex-col p-10 lg:p-20 justify-center">
          <div className="w-full flex flex-col mb-5">
            <h1 className="text-2xl flex flex-col mb-4">Register Page</h1>
            <p className="text-base mb-2">Enter As An Employee</p>
          </div>

          <form onSubmit={handleRegister}>
            <div className="mb-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full placeholder:text-black py-4 my-2 bg-transparent border-b border-black outline-none focus:outline-none"
                placeholder="Enter The email"
              />
            </div>
             <div className="mb-4">
              <input
                type="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full placeholder:text-black py-4 my-2 bg-transparent border-b border-black outline-none focus:outline-none"
                placeholder="Enter The Username"
              />
            </div>
            <div className="mb-6">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full placeholder:text-black py-4 my-2 bg-transparent border-b border-black outline-none focus:outline-none"
                placeholder="Enter The password"
              />
            </div>
            <button
              type="submit"
              className="w-full mb-4 bg-black text-white py-2 px-4 rounded-md flex items-center justify-center hover:bg-red-400"
            >
              Daftar
            </button>
              <Link to ="/" className="text-base mb-2">
            Back
          </Link>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;